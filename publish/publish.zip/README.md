## BrackenFavRoom

Changes the Brackens favorite room to the Backrooms found within the Industrial Layout, given that the room spawns in.

##

<h5>Everything should be fixed and working now. If you find any issues or mod incompatibilitys, please report them on the Github page. Thanks!</h5>

##

### Plans for the future of this mod
- Change the distance the Bracken is allowed to have to its favorite spot before dropping a dead player to be configurable
- Make an option that makes the Backrooms spawn every time on the industrial Layout
- Make other funny or useful Bracken related changes to the game