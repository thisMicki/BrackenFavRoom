## BrackenFavRoom

Changes the Brackens favorite room to the Backrooms found within the Industrial Layout, given that the room spawns in.

##

<h5>Everything should be fixed and working now. If you find any issues or mod incompatibilitys, please report them on the Github page. Thanks!</h5>

##

### Plans for the future of this mod
- Make an option that makes the Backrooms spawn every time on the industrial Layout
- Make other funny or useful Bracken related changes to the game