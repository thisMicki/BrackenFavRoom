## V 0.1.4
- Hopefully I finally made this mod do the one thing it's supposed to
- Copium

## V 0.1.3
- Added incompability flat with SnatchingBracken Mod
- Possibly Fixed Favorite Room position not being set correctly

## V 0.1.2
- Removed log message I accidentally left in which spammed the console when a bracken spawned
- Some performance improvements

## V 0.1.1
- Made it more clear when an Entry is made by this mod
- Possible fix for log spam and other things not working

## V 0.1.0
- Initial Release