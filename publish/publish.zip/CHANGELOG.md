# V 0.1.8
- Fixed a bug causing the favorite position to be set constantly, causing log spam

## V 0.1.7
- The mod is now host only
- Fixed log spam with info that the favorite spot was changed
- Fixed log spam when no Backrooms were generated
- Fixed an issue where the Bracken would be stuck when holding a player due to no path to its favorite room being avalible
- Fixed Backrooms being moved instead of the favorite position of the bracken

## V 0.1.6
- Fixed minor code issues

## V 0.1.5
- Fixed the fav room position to be in the center of the room instead of in front of it

## V 0.1.4
- Hopefully I finally made this mod do the one thing it's supposed to
- Copium

## V 0.1.3
- Added incompability flat with SnatchingBracken Mod
- Possibly Fixed Favorite Room position not being set correctly

## V 0.1.2
- Removed log message I accidentally left in which spammed the console when a bracken spawned
- Some performance improvements

## V 0.1.1
- Made it more clear when an Entry is made by this mod
- Possible fix for log spam and other things not working

## V 0.1.0
- Initial Release