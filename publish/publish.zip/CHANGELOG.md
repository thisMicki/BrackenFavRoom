## V 0.1.2
- Removed log message I accidentally left in wich spammed the console when a bracken spawned
- Some performance improvements

## V 0.1.1
- Made it more clear when an Entry is made by this mod
- Possible fix for log spam and other things not working

## V 0.1.0
- Initial Release